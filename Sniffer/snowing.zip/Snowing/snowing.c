/****************************************************************************
 * Written by Sang-Eun Han (seh@brabo1.korea.ac.kr).
 * 
 * Date :
 *
 * Filename : snowing.c
 *
 *
 * PERMISSION IS GRANTED TO USE, COPY AND DISTRIBUTE THIS SOFTWARE FOR ANY 
 * PURPOSE EXCEPT FOR A BUSINESS OR COMMERCIAL PURPOSE, AND WITHOUT FEE, PROVIDED, 
 * THAT THE ABOVE COPYRIGHT NOTICE AND THIS STATEMENT APPEAR IN ALL COPIES.
 * I MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS
 * SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS PROVIDED "AS IS."
 *
 */

#include <windows.h>
#include <windowsx.h>

#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

#include "packet32.h"
#include "protohdr.h"

BOOLEAN bUserBreak = FALSE;
BOOLEAN bPending = FALSE;
LPADAPTER pAdapter = NULL;
HANDLE hLogFile = NULL;

////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PrintUsage
//
void
PrintUsage(LPTSTR szAppName)
{
	LPTSTR	lpszAppName = szAppName + strlen(szAppName) - 1;
	while(lpszAppName != szAppName && *lpszAppName != '.')	lpszAppName--;
		if(lpszAppName != szAppName) *lpszAppName = 0;
	while(lpszAppName != szAppName && *lpszAppName != '\\')	lpszAppName--;
		if(lpszAppName != szAppName) lpszAppName++;

	fprintf(stderr,_T("SNOWING ver0.1, SNOOP for Windows95, June 20, 1998\n"));
	fprintf(stderr,_T("Author: Sang Eun Mr.Han (seh@brabo1.korea.ac.kr)\n\n"));
	fprintf(stderr,_T("USAGE:\t\t%s [-fFile_Path] [-r#Recv_Packets]\n"), lpszAppName);
	fprintf(stderr,_T("EXAMPLE:\t%s -fsnoop.log -r100\n\n"), lpszAppName);
	fprintf(stderr,_T("DESCRIPTION:\tFile_Path: File name to log packets, opt. \n\t\t\t(default=snowing.log)\n"));
	fprintf(stderr,"\t\t#Recv_Packets: The number of packets logged, opt. \n\t\t\t(default=infinite until user-break\n");
	(void)fflush(stderr);

	return;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
// sighandle for Ctrl+C
//
void 
BreakHandler(int sig)
{
	bUserBreak = TRUE;
	if(bPending == TRUE) {
		if(pAdapter != NULL) {
			//if any pending, it should be cleared.
			PacketResetAdapter(pAdapter);
		}
	}
	signal(SIGINT, BreakHandler);
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FatalError
//
void
FatalError(LPTSTR pFormat, ...)
{
	va_list vaError;

	va_start(vaError, pFormat);
	vfprintf(stderr, pFormat, vaError);
	(void)fflush(stderr);

	exit(1);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ParsePacket
//
typedef struct tagTRANSPORT_PROTOCOLS {
	UCHAR	Protocol;
	TCHAR	szName[20];
	TCHAR	szDescription[MAX_PATH];
} TRANSPORT_PROTOCOLS, *LPTRANSPORT_PROTOCOLS;

//see rfc1340.txt
TRANSPORT_PROTOCOLS transProtos[] = {
	{1 , "ICMP",    "Internet Control Message" },
	{2 , "IGMP",    "Internet Group Management"},
	{3 , "GGP" ,    "Gateway-to-Gateway"},
	{4 , "IP"  ,    "IP in IP (encasulation)"},
	{5 , "ST"  ,    "Stream"},
	{6 , "TCP" ,    "Transmission Control"},
	{8 , "EGP" ,    "Exterior Gateway Protocol"},
	{9 , "IGP" ,    "any private interior gateway"},
	{17, "UDP" ,    "User Datagram"},
	{27, "RDP" ,    "Reliable Data Protocol"},
	{28, "IRTP",    "Internet Reliable Transaction"},
	{29, "ISO-TP4" ,  "ISO Transport Protocol Class 4"},
	{35, "IDPR"    ,  "Inter-Domain Policy Routing Protocol"},
	{37, "DDP"     ,  "Datagram Delivery Protocol"},
	{38, "IDPR-CMTP", "IDPR Control Message Transport Proto"},
	{88, "IGRP"     , "IGRP"},
	{89, "OSPFIGP"  , "OSPFIGP"},
	{92, "MTP"      , "Multicast Transport Protocol"},
	{94, "IPIP"     , "IP-within-IP Encapsulation Protocol"},
	{97, "ETHERIP"  , "Ethernet-within-IP Encapsulation"},
	{98, "ENCAP"    , "Encapsulation Header"}
};
#define TRANSPROTOS_MAX	(sizeof(transProtos)/sizeof(TRANSPORT_PROTOCOLS))

void
ParsePacket(
	HANDLE	hFile, 
	DWORD	nIndex,
	UCHAR	*uBuffer, 
	DWORD	dwBytes)
{
	PETHERNET_HDR	pEthFrame;
	TCHAR szMsg[1024];
	DWORD dwWBytes, dwWrittenBytes;
	USHORT usLengthType;

	register int i;

	if(hFile==NULL) return;
	if(dwBytes == 0) return;

	pEthFrame = (PETHERNET_HDR)uBuffer;

	//MAC Header 
	wsprintf(szMsg,_T("\n[%u th packet, size of %u]\r\n"), nIndex, dwBytes);
	dwWBytes = lstrlen(szMsg);
	WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);
	//mac source address
	wsprintf(szMsg,_T("MAC Source        : %02X:%02X:%02X:%02X:%02X:%02X (in Hex)\r\n"),
		pEthFrame->Source[0],pEthFrame->Source[1],pEthFrame->Source[2],
		pEthFrame->Source[3],pEthFrame->Source[4],pEthFrame->Source[5]);
	dwWBytes = lstrlen(szMsg);
	WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);
	//mac destination address
	wsprintf(szMsg,_T("MAC Destination   : %02X:%02X:%02X:%02X:%02X:%02X (in Hex)\r\n"),
		pEthFrame->Destination[0],pEthFrame->Destination[1],pEthFrame->Destination[2],
		pEthFrame->Destination[3],pEthFrame->Destination[4],pEthFrame->Destination[5]);
	dwWBytes = lstrlen(szMsg);
	WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);
	//mac type or ieee802.3 length field
	usLengthType = TOUSHORT(pEthFrame->Protocol);
	if(usLengthType <= 0x05DC) { //see rfc1340 : assigned numbers
		wsprintf(szMsg,_T("IEEE802.3 Length  : %u\r\n"), usLengthType);
	} else {
		wsprintf(szMsg,_T("MAC User Protocol : 0x%02X%02X\r\n"), 
				pEthFrame->Protocol[0],pEthFrame->Protocol[1]);
	}
	dwWBytes = lstrlen(szMsg);
	WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);

	//in case of the mac type of 0x0800, that is, ip datagram,
	//analysizing the packet in more detail.
	if(usLengthType == PROTO_IP) {
		PIP_RHDR pIP = (PIP_RHDR)pEthFrame->Data;

		//ip source
		wsprintf(szMsg,_T("IP Source      : %u.%u.%u.%u\r\n"),
				pIP->Source[0],pIP->Source[1],pIP->Source[2],pIP->Source[3]);
		dwWBytes = lstrlen(szMsg);
		WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);
		//ip destination
		wsprintf(szMsg,_T("IP Destination : %u.%u.%u.%u\r\n"),
			pIP->Destination[0],pIP->Destination[1],pIP->Destination[2],pIP->Destination[3]);
		dwWBytes = lstrlen(szMsg);
		WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);
		//uppper layer protocol type
		for(i=0; i<TRANSPROTOS_MAX; i++) {		
			if(transProtos[i].Protocol == pIP->Protocol) break;
		}
		if(i==TRANSPROTOS_MAX) {
			wsprintf(szMsg,_T("Upper Layer Protocol : %u\r\n"), pIP->Protocol);
			dwWBytes = lstrlen(szMsg);
			WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);
		} else {
			wsprintf(szMsg,_T("Upper Layer Protocol : %s(%u;%s)\r\n"), 
				transProtos[i].szName,transProtos[i].Protocol, transProtos[i].szDescription);
			dwWBytes = lstrlen(szMsg);
			WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);

			if(transProtos[i].Protocol==6) {
				PTCP_RHDR pTCP = (PTCP_RHDR)(pEthFrame->Data+20);
				wsprintf(szMsg,_T("TCP Seq : %u\r\n"), TOULONG(pTCP->Seq));
				dwWBytes = lstrlen(szMsg);
				WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);
				wsprintf(szMsg,_T("TCP Ack : %u\r\n"),  TOULONG(pTCP->Ack));
				dwWBytes = lstrlen(szMsg);
				WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);
				wsprintf(szMsg,_T("TCP FLAG : 0x%x\r\n"),  pTCP->Flags);
				dwWBytes = lstrlen(szMsg);
				WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);
				wsprintf(szMsg,_T("TCP Window : %u\r\n"),  TOUSHORT(pTCP->Window));
				dwWBytes = lstrlen(szMsg);
				WriteFile(hFile, szMsg, dwWBytes, &dwWrittenBytes, NULL);





			}
		}

		//in case of TCP, you can do it.
		//...

	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
// main
//
int 
main(int argc, char *argv[])
{
	TCHAR szLogPath[MAX_PATH] = {0,};
	DWORD dwRxLoop = 0, dwRxLoopMax = 0;
	int i, j;
	char *p;

	ADAPTER_DESC adapterDescs[5];
	UCHAR uMac[6] = {0,}; //Mac Address
	UCHAR uBuffer[1520]; //Max. Ethernet PDU (Header Len(14)+Payload Len(1504))
	DWORD dwRxBytes;
	LPPACKET pPacket;

	//parse the arguments list
	for(i=1; i<argc; i++) {
		if(*argv[i]=='-' || *argv[i]=='/') {
			p=argv[i]+1;
			switch(*p) {
			case	'f' :
			case	'F' :
				if(lstrlen(p+1) > 0)	
					lstrcpy(szLogPath,p+1);
				break;
			case	'r' :
			case	'R' :
				dwRxLoopMax = atoi(p+1);
				if(dwRxLoopMax < 0) dwRxLoopMax = 0;
				break;
			case	'?' :
			case	'h' :
			default	    :
				PrintUsage(argv[0]);
				return 0;
			}
		} else {
			PrintUsage(argv[0]);
			return 0;
		}
	}

	if(lstrlen(szLogPath) < 1) {
		lstrcpy(szLogPath,_T("snowing.log"));
	}

	//banner
	fprintf(stdout,_T("SNOWING ver0.1, SNOOP for Windows95, June 20, 1998\n"));
	fprintf(stdout,_T("Author: Sang Eun Mr.Han (seh@brabo1.korea.ac.kr)\n"));
	fprintf(stdout,_T("type -? as an option for help\n"));
	fflush(stdout);

	//get the adapters list
	//if the number of the found adapters is greater than 1, then
	//let the user choose the appropriate one.
	if(PacketGetAdapterNames(adapterDescs, 5, &j) == FALSE) {
		FatalError(_T("NIC not found\n"));		
	} else if(j>1) {
		while(TRUE) {
			fprintf(stdout,_T("\nFound %u NICs:\n"),j);
			for(i=0; i<j; i++) {
				fprintf(stdout, _T("\t[%u] %s\n"), i, adapterDescs[i].szAdapterDesc);
			}
			fprintf(stdout,_T("\t[%u] Cancel\n"), i);
			fprintf(stdout,_T("Choose the one:"));
			fflush(NULL);		
			fscanf(stdin,"%u", &i);
			if(i==j) return 0;
			if((i>=0) && (i<j)) break;
		}
	} else {
		i = 0;
	}

	//signal handler for Ctrl+C
	signal(SIGINT, BreakHandler);

	//open the underlying adapter
	//The Adapter Name is represented as "0000", "0001", etc.
	pAdapter = (LPADAPTER)PacketOpenAdapter(adapterDescs[i].szAdapterName);
	if(pAdapter==NULL) {
		FatalError(_T("Adapter %s open failed.\n"), adapterDescs[i].szAdapterName);
	}

	//
	if(PacketAdapterDesc(pAdapter, uBuffer, sizeof(uBuffer), &i)==TRUE) {
		fprintf(stdout,_T("NIC says, 'This is %s.'\n"), uBuffer);
	}

	//Get the current MAC address
	if(PacketGetAddress(pAdapter, uMac, 6, &i) == TRUE) {
		fprintf(stdout,_T("Mac address: %02X:%02X:%02X:%02X:%02X:%02X\n"),
					uMac[0],uMac[1],uMac[2],uMac[3],uMac[4],uMac[5]);
	}

	//Select the packet mode
	//In this case, promiscuous mode is applied to receive any packets
	//being passed over the transmission line attached to this PC.
	if(PacketSetFilter(pAdapter, NDIS_PACKET_TYPE_PROMISCUOUS)==TRUE) {
		fprintf(stdout,_T("Promiscuous mode activated\n"));
	}

	//allocate packet
	pPacket = PacketAllocatePacket(pAdapter);
	if(pPacket == NULL) {
		PacketCloseAdapter(pAdapter);
		FatalError(_T("Packet allocation failed.\n"));
	}

	//set the packet's buffer and its max. length
	PacketInitPacket(pPacket, uBuffer, 1520);

	fprintf(stdout,_T("Start receiving packets...\n"));
	fprintf(stdout,_T("Logs are stored into %s file\n"), szLogPath);
	fprintf(stdout,_T("Press Ctrl+C to abort receiving and exit.\n"));

	//create the log file
	hLogFile = CreateFile(szLogPath, GENERIC_WRITE,	0, NULL,
						CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	//PacketResetAdapter(pAdapter);
	while(TRUE) {
		dwRxBytes = 0;
		bPending = TRUE;
		//receive a packet
		PacketReceivePacket(pAdapter, pPacket, TRUE, &dwRxBytes);
		bPending = FALSE;
		if(bUserBreak == TRUE)	break;

		//process here
		fprintf(stdout,_T("\r%u\t\t"), ++dwRxLoop);
		ParsePacket(hLogFile, dwRxLoop, uBuffer, dwRxBytes);

		if(dwRxLoopMax==0) {
			continue;
		} else if(dwRxLoopMax<=dwRxLoop){
			break;
		}
	}

	fprintf(stdout,_T("\nTotal %u packets received\n\nBye."), dwRxLoop);
	fflush(stdout);

	if(hLogFile != NULL) 
		CloseHandle(hLogFile);

	//free packet
	PacketFreePacket(pPacket);
	//close the underlying adapter
	PacketCloseAdapter(pAdapter);

	return 0;
}
