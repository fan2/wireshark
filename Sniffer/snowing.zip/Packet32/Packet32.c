/****************************************************************************
 * Written by Sang-Eun Han (seh@brabo1.korea.ac.kr).
 * 
 * Date :
 *
 * Filename : Packet32.c
 *
 * PERMISSION IS GRANTED TO USE, COPY AND DISTRIBUTE THIS SOFTWARE FOR ANY 
 * PURPOSE EXCEPT FOR A BUSINESS OR COMMERCIAL PURPOSE, AND WITHOUT FEE, PROVIDED, 
 * THAT THE ABOVE COPYRIGHT NOTICE AND THIS STATEMENT APPEAR IN ALL COPIES.
 * I MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS
 * SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS PROVIDED "AS IS."
 *
 */

#include <windows.h>
#include <windowsx.h>

#include <tchar.h>

//from NT
#include "ntddndis.h"
#include "ntddpack.h"
//
#include "packet32.h"
#include "ZPacket.h"


CHAR	szWindowTitle[] = "PACKET32.DLL";
HANDLE	hInstance;

BOOLEAN	 WINAPI
PacketInit (HANDLE hInst, 
			ULONG ul_reason_for_call,
			LPVOID lpReserved)
{
	switch(ul_reason_for_call) {
	case DLL_PROCESS_ATTACH:
		hInstance = hInst;
		break;
	case DLL_PROCESS_DETACH:
		break;
	default:
		break;
	}

	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketOpenAdapter
//
PVOID  WINAPI
PacketOpenAdapter(
	LPTSTR   AdapterName	// 0000, 0001, etc.
	)
{
	LPADAPTER	lpAdapter;
	BOOLEAN		Result;
	DWORD		dwReturn;

	lpAdapter=(LPADAPTER)GlobalAllocPtr(GMEM_MOVEABLE | GMEM_ZEROINIT, sizeof(ADAPTER));
	if(lpAdapter==NULL) {
		return NULL;
	}

	lstrcpy(lpAdapter->SymbolicLink,_T("\\\\.\\ZPACKET.VXD"));
	wsprintf(lpAdapter->szAdapterName,_T("%s"), AdapterName);
	lpAdapter->hFile= CreateFile(lpAdapter->SymbolicLink, GENERIC_READ | GENERIC_WRITE,
								0, NULL, OPEN_EXISTING,
								FILE_ATTRIBUTE_NORMAL | FILE_FLAG_DELETE_ON_CLOSE | FILE_FLAG_OVERLAPPED,
								NULL);

	if(lpAdapter->hFile != INVALID_HANDLE_VALUE) {
		HANDLE		hEvent;
		OVERLAPPED	Ovrlapped = {0, 0, 0, 0, 0 };
	
		hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
		if(hEvent == NULL) {
			CloseHandle(lpAdapter->hFile);
		} else {
			Ovrlapped.hEvent = hEvent;
			Result = DeviceIoControl( lpAdapter->hFile, IOCTL_ZPACKET_BIND,
										AdapterName, strlen(AdapterName), NULL, 0,
										&dwReturn, &Ovrlapped);
			if(Result == FALSE) {	
				// pending...
				Result = GetOverlappedResult(lpAdapter->hFile, &Ovrlapped, &dwReturn,TRUE);
			}
			if(Result == FALSE) {
				CloseHandle(lpAdapter->hFile);
				GlobalFreePtr(lpAdapter);
				return NULL;
			}
		}
		//flush receive queue
		//DeviceIoControl(lpAdapter->hFile, IOCTL_ZPACKET_FLUSH, NULL, 0, NULL, 0, NULL, NULL);
	} else {
		GlobalFreePtr(lpAdapter);
		return NULL;
	}

	return (lpAdapter);
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketCloseAdapter
//
VOID WINAPI
PacketCloseAdapter(
	LPADAPTER   lpAdapter
	)
{
	HANDLE		hEvent;
	OVERLAPPED	Ovrlapped = {0, 0, 0, 0, 0 };
	BOOLEAN		Result;
	DWORD		dwReturn;
	
	
	hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	if(hEvent != NULL) {
		Ovrlapped.hEvent = hEvent;
		Result = DeviceIoControl(	lpAdapter->hFile, 
						  			IOCTL_ZPACKET_UNBIND,
									NULL, 0, NULL, 0,
									&dwReturn, &Ovrlapped);
		if(Result == FALSE) {	
			// pending...
			Result = GetOverlappedResult(lpAdapter->hFile,&Ovrlapped, &dwReturn,TRUE);
		}
	}

	CloseHandle(lpAdapter->hFile);
	GlobalFreePtr(lpAdapter);
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketAllocatePacket
//
PVOID  WINAPI
PacketAllocatePacket(
	LPADAPTER   AdapterObject
	)
{
	LPPACKET	lpPacket;
	
	lpPacket= (LPPACKET)GlobalAllocPtr(GMEM_MOVEABLE | GMEM_ZEROINIT, sizeof(PACKET));

	if (lpPacket==NULL) {
		return NULL;
	}

	lpPacket->OverLapped.hEvent=CreateEvent(NULL, FALSE, FALSE, NULL);

	if (lpPacket->OverLapped.hEvent==NULL) { 
		GlobalFreePtr(lpPacket);
		return NULL;
	}

	return lpPacket;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketFreePacket
//
VOID WINAPI
PacketFreePacket(
	LPPACKET    lpPacket
	)
{
	CloseHandle(lpPacket->OverLapped.hEvent);
	GlobalFreePtr(lpPacket);
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketInitPacket
//
VOID WINAPI
PacketInitPacket(
	LPPACKET	lpPacket,
	PVOID		Buffer,
	UINT		Length
	)
{
	if(lpPacket==NULL) {
		// panic!
		return;
	}

    lpPacket->Buffer=Buffer;
    lpPacket->Length=Length;
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketSendPacket
//
// NOTE: Sync information is ignored.
BOOLEAN	WINAPI
PacketSendPacket(
	LPADAPTER	AdapterObject,
	LPPACKET	lpPacket,
	BOOLEAN		Sync
	)
{
	BOOLEAN		Result;
	DWORD		BytesTransfered;

	lpPacket->OverLapped.Offset=0;
	lpPacket->OverLapped.OffsetHigh=0;

	if(!ResetEvent(lpPacket->OverLapped.hEvent)) {
		return FALSE;
	}

	Result = DeviceIoControl(AdapterObject->hFile, IOCTL_ZPACKET_SEND,
							lpPacket->Buffer, lpPacket->Length,	NULL, 0, 
							&BytesTransfered, &lpPacket->OverLapped);

	if(Result == FALSE) {
		//pending
		Result = GetOverlappedResult(AdapterObject->hFile, &lpPacket->OverLapped,
										&BytesTransfered, TRUE);
	} 
	
	return Result;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketReceivePacket
//
BOOLEAN	 WINAPI
PacketReceivePacket(
	LPADAPTER	AdapterObject,
	LPPACKET	lpPacket,
	BOOLEAN		Sync,
	PULONG		BytesReceived
	)
{
	BOOLEAN      Result;

	lpPacket->OverLapped.Offset=0;
	lpPacket->OverLapped.OffsetHigh=0;

	if (!ResetEvent(lpPacket->OverLapped.hEvent)) {
		return FALSE;
	}

	Result = DeviceIoControl(	AdapterObject->hFile, IOCTL_ZPACKET_RECEIVE,
								NULL, 0, lpPacket->Buffer, lpPacket->Length,
								BytesReceived,&lpPacket->OverLapped);
	if((Result == FALSE) && (Sync == TRUE)) {
		Result = GetOverlappedResult(AdapterObject->hFile, &lpPacket->OverLapped,
										BytesReceived, TRUE);
	} 

	return Result;

}


////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketWaitPacket
//
BOOLEAN	 WINAPI
PacketWaitPacket(
	LPADAPTER	AdapterObject,
	LPPACKET	lpPacket,
	PULONG		BytesReceived
	)
{
    return GetOverlappedResult(AdapterObject->hFile, &lpPacket->OverLapped, 
								BytesReceived, TRUE);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketResetAdapter
//
BOOLEAN	WINAPI
PacketResetAdapter(
	LPADAPTER	AdapterObject
	)
{
	//just flush
	//if pending, clear this pending
	DeviceIoControl(AdapterObject->hFile, IOCTL_ZPACKET_FLUSH, 
					NULL, 0, NULL, 0, NULL, NULL);

	DeviceIoControl(AdapterObject->hFile, IOCTL_ZPACKET_CLEAR_PEND,
					NULL, 0, NULL, 0, NULL, NULL);

    return TRUE;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketSetFilter
//
BOOLEAN	WINAPI
PacketSetFilter(
	LPADAPTER	AdapterObject,
	ULONG		Filter
	)
{
	HANDLE		hEvent;
	OVERLAPPED	Ovrlapped = {0, 0, 0, 0, 0 };
	BOOLEAN		Result;
	DWORD		dwReturn;
	DWORD		dwMode = Filter;
	
	
	hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);	// must be manual-reset
	if(hEvent == NULL) {
		return FALSE;
	}

	Ovrlapped.hEvent = hEvent;

	Result = DeviceIoControl(	AdapterObject->hFile, IOCTL_ZPACKET_SET_PACKET_FILTER,
								&dwMode, sizeof(DWORD), NULL, 0,
								&dwReturn,	&Ovrlapped);

	if(Result == FALSE) {
		// pending...
		Result = GetOverlappedResult(AdapterObject->hFile, &Ovrlapped, &dwReturn, TRUE);
	}

	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketGetAddress
//
BOOLEAN	 WINAPI
PacketGetAddress(
	LPADAPTER  AdapterObject,
	PUCHAR     AddressBuffer,
	DWORD		cbBytes, 
	LPDWORD		lpcbBytes
	)
{
	
	HANDLE		hEvent;
	OVERLAPPED	Ovrlapped = {0, 0, 0, 0, 0 };
	BOOLEAN		Result;

	if(AddressBuffer == NULL) {
		return FALSE;
	}

	if((lpcbBytes==NULL) || (cbBytes < 6)) {
		return FALSE;
	}

	hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);	// must be manual-reset
	if(hEvent == NULL)	{
		return FALSE;
	}

	Ovrlapped.hEvent = hEvent;
	Result = DeviceIoControl(	AdapterObject->hFile, IOCTL_ZPACKET_MAC_ADDRESS,
								NULL, 0, AddressBuffer, cbBytes,
								lpcbBytes, &Ovrlapped);

	if(Result == FALSE) {	// pending...
		Result = GetOverlappedResult( AdapterObject->hFile,&Ovrlapped,lpcbBytes,TRUE);
	}

    return Result;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketAdapterDesc
//
BOOLEAN WINAPI
PacketAdapterDesc(
		LPADAPTER	AdapterObject,
		LPSTR		lpszVendorSays, 
		DWORD		cbBytes, 
		LPDWORD		lpcbBytes
		)
{
	HANDLE		hEvent;
	OVERLAPPED	Ovrlapped = {0, 0, 0, 0, 0 };
	BOOL		Result;
	
	*lpcbBytes = 0;
	hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);	// must be manual-reset
	if(hEvent == NULL) {
		return FALSE;
	}

	Ovrlapped.hEvent = hEvent;

	Result = DeviceIoControl(	AdapterObject->hFile, IOCTL_ZPACKET_VENDOR_DESCRIPTION,
								NULL, 0, lpszVendorSays, cbBytes,
								lpcbBytes, &Ovrlapped);

	if(Result == FALSE) {
		// pending...
		Result = GetOverlappedResult(AdapterObject->hFile, &Ovrlapped, lpcbBytes, TRUE);
	}

	return Result;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PacketGetAdapterNames
//
ULONG  WINAPI
PacketGetAdapterNames(
	PVOID	pAdapterDescs,
	UINT	nAdapterDescs,
	PUINT	pnAdapterDescsMax
	)
{
	HKEY	Key, SubKey;
	CHAR	KeyPath[256], SubKeyPath[256];
	LONG	Status;
	DWORD	dwSubKeys, Index;
	DWORD	cbBytes;
	LPADAPTER_DESC	pAdapterDesc = (LPADAPTER_DESC)pAdapterDescs;

	FILETIME ft;

	lstrcpy(KeyPath,"System\\CurrentControlSet\\Services\\Class\\Net");
	Status=RegOpenKeyEx(
			HKEY_LOCAL_MACHINE,
			KeyPath,
			0,
			KEY_READ,
			&Key);

	if(Status == ERROR_SUCCESS) {
		dwSubKeys = 0;
		Status = RegQueryInfoKey ( Key, NULL, NULL, NULL,
					&dwSubKeys,	NULL, NULL, NULL,
					NULL, NULL, NULL, &ft);
		if(dwSubKeys == 0 || Status != ERROR_SUCCESS) {
			RegCloseKey(Key);
			return FALSE;
		}
		
		//enumerate
		for(Index = 0; Index < dwSubKeys; Index++) {
			if(nAdapterDescs <= Index) break;

			cbBytes = sizeof(pAdapterDesc[Index].szAdapterName);
			Status = RegEnumKeyEx(Key, Index,
						pAdapterDesc[Index].szAdapterName, &cbBytes,
						NULL, NULL, NULL, &ft);
			if(Status != ERROR_SUCCESS) break;

			wsprintf(SubKeyPath,"%s\\%s", KeyPath, pAdapterDesc[Index].szAdapterName);
			Status=RegOpenKeyEx(HKEY_LOCAL_MACHINE, SubKeyPath, 0,KEY_READ,&SubKey);
			if(Status != ERROR_SUCCESS) continue;

			cbBytes = sizeof(pAdapterDesc[Index].szAdapterDesc);
			(void)RegQueryValueEx(SubKey,_T("DriverDesc"),
						NULL,NULL, pAdapterDesc[Index].szAdapterDesc, &cbBytes);
			RegCloseKey(SubKey);
		}
	}

	*pnAdapterDescsMax = Index;
	RegCloseKey(Key);
	if(Index == 0) {
		return FALSE;
	} else {
		return TRUE;
	}
}