#ifndef __NTDDPACKET
#define __NTDDPACKET 1

#include "packon.h"

typedef struct _PACKET_OID_DATA {
    ULONG           Oid;
    ULONG           Length;
    UCHAR           Data[1];
}   PACKET_OID_DATA, *PPACKET_OID_DATA;

#include "packoff.h"

#endif