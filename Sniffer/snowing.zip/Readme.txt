Hi!

This is README file for snowing ver 0.2 (date:2-29-1999).

(C) Copyright 1998, 1999. Sang-Eun Han.
All rights reserved.
______________________________________________

Distribution

  You may freely distribute this software among friends, or even send
this software on to internet forums, but only in the same form as 
which you got it in. 

-------------------------------------------------------------------

Contact information

  If you are having difficulty in installing/using the software,
or reporting bugs, please feel free to contact me in:

    email:  seh@brabo1.korea.ac.kr

    URL:    http://widecomm.korea.ac.kr/~seh

------------------------------------------------------------------

DISCLAIMER:

ALL DOCUMENTATION AND THE PROGRAM IS PROVIDED "AS IS" WITHOUT 
WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING 
BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND/OR SUITABILITY FOR A PARTICULAR PURPOSE. 
THE USER ASSUMES THE ENTIRE RISK OF ANY DAMAGE CAUSED BY 
THIS SOFTWARE. 

IN NO EVENT SHALL I BE LIABLE FOR DAMAGE OF ANY KIND, LOSS OF DATA, 
LOSS OF PROFITS, BUSINESS INTERRUPTION OR OTHER PECUNIARY LOSS 
ARISING DIRECTLY OR INDIRECTLY.

------------------------------------------------------------------

Installation and Execution

1. unzip the file into your desired directory.
   (e.g. YOUR_ROOT = c:\snowing)
2. move to the directory, $(YOUR_ROOT)\snowing\release
3. execution snowing.exe. 
4. press ctrl+c to exit.
5. use any installed text editor to view snowing.log file which logs 
   the packets. 
   (e.g. edit snowing.log)

NOTE: Be sure that you have all the files, snowing.exe, packet32.dll, and
      zpacket.vxd in the same directory.
      If it is inconvienent, copy packet32.dll and zpacket to the windows
      system directory. (e.g. c:\windows\system)

------------------------------------------------------------------

Implementation Environment

1. For both snowing application and packet32 library, I use Visual C++ 5.0
2. For zpacket.vxd, I use Win95 DDK and Win32 SDK. Even though I use DDK95,
   it works on Win98.

------------------------------------------------------------------

Thanks for giving me the chance to contact you!

Have a fun!
