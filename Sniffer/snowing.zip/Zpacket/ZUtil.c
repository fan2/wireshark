/****************************************************************************
 * Written by Sang-Eun Han (seh@brabo1.korea.ac.kr).
 * 
 * Date : July 28, 1997
 *
 * Filename : ZUtil.c
 *
 * PERMISSION IS GRANTED TO USE, COPY AND DISTRIBUTE THIS SOFTWARE FOR ANY 
 * PURPOSE EXCEPT FOR A BUSINESS OR COMMERCIAL PURPOSE, AND WITHOUT FEE, PROVIDED, 
 * THAT THE ABOVE COPYRIGHT NOTICE AND THIS STATEMENT APPEAR IN ALL COPIES.
 * I MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS
 * SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS PROVIDED "AS IS."
 *
 */

#pragma warning(disable:4201 4514 4100 4127)

#define	WANTVXDWRAPS

#include <basedef.h>
#include <vmm.h>
#include <debug.h>
#include <vxdwraps.h>

#include "ZUtil.h"

#pragma VxD_LOCKED_CODE_SEG
#pragma VxD_LOCKED_DATA_SEG
//#pragma VxD_PAGEABLE_CODE_SEG
//#pragma VxD_PAGEABLE_DATA_SEG


DWORD _stdcall XPACKETPageLock(DWORD lpMem, DWORD cbSize)
{
	DWORD LinPageNum, LinOffset, nPages;

	LinOffset = lpMem & 0xfff; // page offset of memory to map
	LinPageNum = lpMem >> 12;  // generate page number

	// Calculate # of pages to map globally
	nPages = ((lpMem + cbSize) >> 12) - LinPageNum + 1;

	//
	// Return global mapping of passed in pointer, as this new pointer
	// is how the memory must be accessed out of context.
	//
	return (_LinPageLock(LinPageNum, nPages, PAGEMAPGLOBAL) + LinOffset);
}

void _stdcall XPACKETPageUnlock(DWORD lpMem, DWORD cbSize)
{
	DWORD LinPageNum, nPages;

	LinPageNum = lpMem >> 12;
	nPages = ((lpMem + cbSize) >> 12) - LinPageNum + 1;

	// Free globally mapped memory
	_LinPageUnlock(LinPageNum, nPages, PAGEMAPGLOBAL);

	return;
}

void __stdcall XPACKETAllocateMemory(PVOID *VirtualMemory, ULONG nBytes)
{
	PVOID	VirtualMemoryLocal;

	VirtualMemoryLocal = (PVOID)_HeapAllocate(
										nBytes,
										(ULONG)(HEAPLOCKEDIFDP|HEAPZEROINIT));

	*VirtualMemory = VirtualMemoryLocal;

	return;
}

void __stdcall XPACKETFreeMemory(PVOID VirtualMemory)
{
	(void)_HeapFree(VirtualMemory, 0);

	return;
}

