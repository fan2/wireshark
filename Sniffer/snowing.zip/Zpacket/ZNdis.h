/****************************************************************************
 * Written by Sang-Eun Han (seh@brabo1.korea.ac.kr).
 * 
 * Date : July 28, 1997
 *        March 13, 1998
 *
 * Filename : ZNDIS.h
 *
 * PERMISSION IS GRANTED TO USE, COPY AND DISTRIBUTE THIS SOFTWARE FOR ANY 
 * PURPOSE EXCEPT FOR A BUSINESS OR COMMERCIAL PURPOSE, AND WITHOUT FEE, PROVIDED, 
 * THAT THE ABOVE COPYRIGHT NOTICE AND THIS STATEMENT APPEAR IN ALL COPIES.
 * I MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS
 * SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS PROVIDED "AS IS."
 *
 */

#ifndef _ZNDIS_H
#define _ZNDIS_H

#define XPACKET_NDIS_MAJOR_VERSION	0x03
#define XPACKET_NDIS_MINOR_VERSION	0x0A

#ifndef LPCHAR
typedef CHAR    *LPCHAR;
#endif

#ifndef LPDWORD
typedef DWORD   *LPDWORD;
#endif

#ifndef LPOVERLAPPED
typedef OVERLAPPED      *LPOVERLAPPED;
#endif

#define	XPACKET_FLUSHING		0x1

#define XPACKET_C_NAME                  "ZPACKET"

typedef struct	_XPACKET_LOCK {
	DWORD		Status;
	DWORD		lpBuffer;
	DWORD		lpcbBytesReturned;
	DWORD		lpoOvrlapped;		// can be NULL
	DWORD		cbBuffer;			// don't lock this
} XPACKET_LOCK, *PXPACKET_LOCK;

//////////////////////////////////////////////////////////////////////////////////
#define MAX_BUFFER_LENGTH		1520	//Ethernet MTU size	+ Header Size
#define MAX_RECVQ_LENGTH        100	//Total 1520 * MAX_RECVQ_LENGTH =  148K or so

// BindAdapter status
#define	XPACKET_BIND_ADAPTER_FREE	0x00000000
#define	XPACKET_BIND_ADAPTER_PEND	0x00000001
// UnbindAdapter status
#define	XPACKET_UNBIND_ADAPTER_FREE	0x00000000
#define	XPACKET_UNBIND_ADAPTER_PEND	0x00000001

// Each receive queue entry status
#define	XPACKET_RX_READY	0x00000001
#define	XPACKET_RX_FREE		0x00000002
#define	XPACKET_RX_CAOS		0x00000004
#define	XPACKET_RX_PEND		0x00000008

typedef
struct	_XPACKET_BUFFER {
	PCHAR			lpBuffer;
	DWORD			cbBuffer;	// in bytes
	DWORD			Status;		// see the above flags
} XPACKET_BUFFER, *PXPACKET_BUFFER;


//////////////////////////////////////////////////////////////////////////////////
#define MAX_PACKET_POOL         15
#define MAX_BUFFER_POOL         15

//NDIS_PACKET's reserved area
typedef
struct _XPACKET_RESERVED {
	DWORD	lpBuffer;		
	DWORD	cbBuffer;
	DWORD	lpoOvrlapped;
	DWORD	lpcbBytesReturned;	
} XPACKET_RESERVED, *PXPACKET_RESERVED;	// Total size of 16 octets

#define PACKET_RESERVE(p)	((PXPACKET_RESERVED)((p)->ProtocolReserved))

#define	XPACKET_MOD_INC(x,y)		(((x)+1) % (y))

// use to determine what ring3 process we deal with.
typedef
struct _PROCESS_FACE {		
	DWORD	VMHandle;
	DWORD	hDevice;
	DWORD	tagProcess;
} PROCESS_FACE, *PPROCESS_FACE;

// General description about OPEN_INSTANCE
// 1. Each OPEN_INSTANCE has only one receive queue of 
//    the max. length of MAX_RECVQ_LENGTH.
// 2. A receive queue operates similar to a circular queue.
typedef	struct _OPEN_INSTANCE {
	NDIS_STATUS		Status;

	DWORD			Flushing;	//pending and flushing state
	PROCESS_FACE	ProcessFace;

	NDIS_HANDLE		hAdapter;
	NDIS_HANDLE		hBindAdapterContext;

	// synchronous requset set and query
	// request page locking  
	NDIS_REQUEST		NdisRequest;
	DWORD				lpBuffer;		
	DWORD				cbBuffer;
	DWORD				lpoOvrlapped;
	DWORD				lpcbBytesReturned;	

	// receive queue
	XPACKET_BUFFER		RecvQueue[MAX_RECVQ_LENGTH];
	UINT				RecvQMaxEntries;
	UINT				RecvHead;
	UINT				RecvTail;
	XPACKET_LOCK		RecvPendQueue;

	// pool
	NDIS_HANDLE			hPacketPool;
	NDIS_HANDLE			hBufferPool;

	struct	_OPEN_INSTANCE	*pNextOpenInstance;
} OPEN_INSTANCE, *POPEN_INSTANCE;


// PROTOCOL_BLOCK
typedef	struct _PROTOCOL_BLOCK {
	DWORD			dwOpenInstances;		

	NDIS_HANDLE		hProtocol;

	//used in the case of ZPACKET_BIND
	//Locking the user-supplied buffer containing the AdapterName information
	XPACKET_LOCK	BindAdapterLock;
	//used in the case of ZPACKET_UNBIND
	XPACKET_LOCK	UnbindAdapterLock;

	POPEN_INSTANCE	pNextOpenInstance;	//Linked-List of OPEN_INSTANCES
} PROTOCOL_BLOCK, *PPROTOCOL_BLOCK;

extern PROTOCOL_BLOCK 	XPACKETContext;		//see ZNDIS.C


//////////////////////////////////////////////////////////////////////////////////
NTSTATUS NDIS_API
DriverEntry(
       IN PDRIVER_OBJECT       DriverObject,	// NULL in Windows95 CHICAGO 
       IN PUNICODE_STRING      RegistryPath	// NULL in Windows95 CHICAGO
       );

VOID NDIS_API
XPACKETBindAdapterComplete(
    IN NDIS_HANDLE  ProtocolBindingContext,
    IN NDIS_STATUS  Status,
    IN NDIS_STATUS  OpenErrorStatus
    );

VOID NDIS_API
XPACKETUnbindAdapterComplete(
    IN NDIS_HANDLE  ProtocolBindingContext,
    IN NDIS_STATUS  Status
    );


NDIS_STATUS NDIS_API
XPACKETReceiveIndicate(
    IN NDIS_HANDLE ProtocolBindingContext,
    IN NDIS_HANDLE MacReceiveContext,
    IN PVOID HeaderBuffer,
    IN UINT HeaderBufferSize,
    IN PVOID LookAheadBuffer,
    IN UINT LookAheadBufferSize,
    IN UINT PacketSize
    );

VOID NDIS_API
XPACKETReceiveComplete(
    IN NDIS_HANDLE  ProtocolBindingContext
    );

VOID NDIS_API
XPACKETRequestComplete(
    IN NDIS_HANDLE   ProtocolBindingContext,
    IN PNDIS_REQUEST pRequest,
    IN NDIS_STATUS   Status
    );

VOID NDIS_API
XPACKETSendComplete(
    IN NDIS_HANDLE   ProtocolBindingContext,
    IN PNDIS_PACKET  pPacket,
    IN NDIS_STATUS   Status
    );

VOID NDIS_API
XPACKETResetComplete(
    IN NDIS_HANDLE  ProtocolBindingContext,
    IN NDIS_STATUS  Status
    );


VOID NDIS_API
XPACKETStatus(
	IN NDIS_HANDLE   	ProtocolBindingContext,
	IN NDIS_STATUS   	Status,
        IN PVOID                StatusBuffer,
        IN UINT                 StatusBufferSize
    );


VOID NDIS_API
XPACKETStatusComplete(
	IN NDIS_HANDLE 	ProtocolBindingContext
	);


VOID NDIS_API
XPACKETTransferDataComplete(
	IN NDIS_HANDLE	ProtocolBindingContext,
	IN PNDIS_PACKET	Packet,
	IN NDIS_STATUS	Status,
	IN UINT			BytesTransferred
	);


VOID NDIS_API
XPACKETUnload(VOID);

VOID NDIS_API
XPACKETBindAdapter( 
	OUT PNDIS_STATUS Status,
	IN  NDIS_HANDLE  BindAdapterContext,
	IN  PNDIS_STRING AdapterName,
	IN  PVOID        SystemSpecific1,	// Registry Path, But NULL in Windows95
	IN  PVOID        SystemSpecific2 	// Reserved for System use, but for my use?
	);

VOID NDIS_API
XPACKETUnbindAdapter( 
	OUT PNDIS_STATUS	Status,
	IN NDIS_HANDLE		ProtocolBindingContext,
	IN NDIS_HANDLE		UnbindContext
	);

void VXDINLINE
VWIN32_DIOCCompletionRoutine(DWORD hEvent)
{
	_asm mov ebx, hEvent
	VxDCall( VWIN32_DIOCCompletionRoutine );
}

//++
NDIS_STATUS __stdcall
XPACKETRequestIoControl (
		IN POPEN_INSTANCE	pOpenInstance,
		IN NDIS_OID			Oid,
		IN DWORD			lpBuffer,
		IN DWORD			cbBuffer,
		IN DWORD			lpcbBytesReturned,
		IN LPOVERLAPPED		lpoOvrlapped,
		IN BOOL				fQuery		// if TRUE, query
		);

NDIS_STATUS __stdcall
XPACKETAllocateBuffer(
	IN	POPEN_INSTANCE	pOpenInstance,
	OUT PNDIS_PACKET	*ppPacket,
	IN  DWORD			lpBuffer,
	IN  DWORD			cbBuffer,
	IN  DWORD			lpcbBytesReturned,			
	IN  LPOVERLAPPED	lpoOvrlapped
	);

POPEN_INSTANCE	__stdcall
XPACKETGetOpenInstance(
	DWORD		VMHandle,
	DWORD		hDevice,
	DWORD		tagProcess
	);


////////////////////////////////////////////////////////////
// mSleep
VOID VXDINLINE mSleep(DWORD msec)
// arguments
//		msec : milisecond to sleep
// return value
{
	_asm mov eax, [msec]
	VMMCall(Time_Slice_Sleep);
}

#endif	// _ZNDIS_H


