/****************************************************************************
 * Written by Sang-Eun Han (seh@brabo1.korea.ac.kr).
 * 
 * Date : July 28, 1997
 *        Aug. 31, 1997 (enhanced)
 *        Feb. 29, 1998 (more enhanced)
 *
 * Filename : ZNdis.c
 *
 * PERMISSION IS GRANTED TO USE, COPY AND DISTRIBUTE THIS SOFTWARE FOR ANY 
 * PURPOSE EXCEPT FOR A BUSINESS OR COMMERCIAL PURPOSE, AND WITHOUT FEE, PROVIDED, 
 * THAT THE ABOVE COPYRIGHT NOTICE AND THIS STATEMENT APPEAR IN ALL COPIES.
 * I MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS
 * SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS PROVIDED "AS IS."
 *
 */
#include <string.h>
#pragma intrinsic(memcpy, memcmp, memset, strcat, strcmp, strcpy, strlen)

#pragma warning(disable:4201 4514 4100 4127)

#include <basedef.h>
#include <vmm.h>
#include <ndis.h>
#include <vwin32.h>
#include <debug.h>

#include "ZNdis.h"
#include "ZUtil.h"

#pragma VxD_LOCKED_CODE_SEG
#pragma VxD_LOCKED_DATA_SEG

PROTOCOL_BLOCK		XPACKETContext={ 0,  };

NTSTATUS NDIS_API
DriverEntry( 
	IN PDRIVER_OBJECT	DriverObject,	// NULL in Windows95 CHICAGO 
	IN PUNICODE_STRING	RegistryPath	// NULL in Windows95 CHICAGO
	)
{
	NDIS_PROTOCOL_CHARACTERISTICS	ProtoChar;
	NDIS_STRING	XPACKETName = NDIS_STRING_CONST((PUCHAR)(XPACKET_C_NAME));
	NDIS_STATUS	Status;

	NdisZeroMemory((UCHAR*)&ProtoChar, sizeof(NDIS_PROTOCOL_CHARACTERISTICS));

	ProtoChar.MajorNdisVersion			= XPACKET_NDIS_MAJOR_VERSION;
	ProtoChar.MinorNdisVersion			= XPACKET_NDIS_MINOR_VERSION;
	ProtoChar.Reserved					= 0;

	ProtoChar.OpenAdapterCompleteHandler  	= XPACKETBindAdapterComplete;
	ProtoChar.CloseAdapterCompleteHandler 	= XPACKETUnbindAdapterComplete;
	ProtoChar.SendCompleteHandler         	= XPACKETSendComplete;
	ProtoChar.TransferDataCompleteHandler 	= XPACKETTransferDataComplete;
	ProtoChar.ResetCompleteHandler        	= XPACKETResetComplete;
	ProtoChar.RequestCompleteHandler      	= XPACKETRequestComplete;
	ProtoChar.ReceiveHandler				= XPACKETReceiveIndicate;
	ProtoChar.ReceiveCompleteHandler		= XPACKETReceiveComplete;
	ProtoChar.StatusHandler					= XPACKETStatus;
	ProtoChar.StatusCompleteHandler       	= XPACKETStatusComplete;

	ProtoChar.BindAdapterHandler	       	= XPACKETBindAdapter;
	ProtoChar.UnbindAdapterHandler        	= XPACKETUnbindAdapter;
	ProtoChar.UnloadProtocolHandler       	= XPACKETUnload;

	ProtoChar.Name                        	= XPACKETName;

	NdisRegisterProtocol(&Status, &XPACKETContext.hProtocol, &ProtoChar,
							sizeof(NDIS_PROTOCOL_CHARACTERISTICS));
	return (Status);
}



VOID NDIS_API
XPACKETUnload()
{
	NDIS_STATUS		Status;

	NdisDeregisterProtocol(&Status, XPACKETContext.hProtocol);

	return;
}


VOID NDIS_API   
XPACKETStatus(
	IN NDIS_HANDLE	ProtocolBindingContext,
	IN NDIS_STATUS	Status,
	IN PVOID        StatusBuffer,
	IN UINT         StatusBufferSize
	)
{
	return;
}


VOID NDIS_API
XPACKETStatusComplete(
	IN NDIS_HANDLE  ProtocolBindingContext
	)
{
	return;
}


VOID NDIS_API
XPACKETBindAdapter(
	OUT PNDIS_STATUS 	pStatus,
	IN  NDIS_HANDLE  	BindAdapterContext,
	IN  PNDIS_STRING 	AdapterName,
	IN  PVOID      		SystemSpecific1,	// Registry Path, But NULL in Windows95
	IN  PVOID      		SystemSpecific2 	// the pointer to the process face
	)
{
	NDIS_STATUS			ErrorStatus;
	UINT           		Index, Medium;
	NDIS_MEDIUM    		MediumArray = NdisMedium802_3;
	POPEN_INSTANCE		pOpenInstance;
	PXPACKET_LOCK		pXPacketLock;
	DWORD				dwPacketFilter;

	PPROCESS_FACE		pProcessFace = (PPROCESS_FACE)SystemSpecific2;

#ifdef	DEBUG
	Debug_Printf("XPACKET:BindAdapter(%s)\n", AdapterName->Buffer);
#endif

	XPACKETAllocateMemory((PVOID *)&pOpenInstance, sizeof(OPEN_INSTANCE));
	if(pOpenInstance == NULL) {
		*pStatus = NDIS_STATUS_RESOURCES;
		return;
	}
	NdisZeroMemory((UCHAR *)pOpenInstance, sizeof(OPEN_INSTANCE));

	pOpenInstance->ProcessFace.VMHandle = pProcessFace->VMHandle;
	pOpenInstance->ProcessFace.hDevice = pProcessFace->hDevice;
	pOpenInstance->ProcessFace.tagProcess = pProcessFace->tagProcess;

	// Save Binding Context, NULL
	pOpenInstance->hBindAdapterContext = BindAdapterContext;

	// Allocate packet pool
	NdisAllocatePacketPool(
                pStatus,
				&pOpenInstance->hPacketPool,
               	MAX_PACKET_POOL,
				sizeof(XPACKET_RESERVED));
	if(*pStatus != NDIS_STATUS_SUCCESS)	{
		XPACKETFreeMemory((PVOID)pOpenInstance);
		return;
	}

	// Allocate buffer pool
	NdisAllocateBufferPool(
		pStatus,
		&pOpenInstance->hBufferPool,
		MAX_BUFFER_POOL); 	
	if(*pStatus != NDIS_STATUS_SUCCESS)	{
		NdisFreePacketPool(pOpenInstance->hPacketPool); 
		XPACKETFreeMemory((PVOID)pOpenInstance);
		return;
	}

	//RECVQ Initialize
	for(Index=0; Index < MAX_RECVQ_LENGTH; Index++) {
		pOpenInstance->RecvQueue[Index].lpBuffer = NULL;
		pOpenInstance->RecvQueue[Index].cbBuffer = 0;
		pOpenInstance->RecvQueue[Index].Status = XPACKET_RX_CAOS;
	}
	pOpenInstance->RecvQMaxEntries = 0;
	pOpenInstance->RecvHead = 0;
	pOpenInstance->RecvTail = 0;
	//PENDQ Initialize
	pOpenInstance->RecvPendQueue.Status = XPACKET_RX_FREE;
	pOpenInstance->RecvPendQueue.lpBuffer = 0;
	pOpenInstance->RecvPendQueue.cbBuffer = 0;
	pOpenInstance->RecvPendQueue.lpoOvrlapped = 0;
	//XPACKETContext.RecvPendQueue.lpcbBytesReturned = 0;

	NdisOpenAdapter( 
		&pOpenInstance->Status, &ErrorStatus,
	  	&pOpenInstance->hAdapter,
		&Medium, &MediumArray, 1,
		XPACKETContext.hProtocol, (NDIS_HANDLE)pOpenInstance, AdapterName,
		0, NULL);

	//Save the status returned by NdisOpenAdapter for completion routine
	if(pOpenInstance->Status != NDIS_STATUS_PENDING) {
		if(pOpenInstance->Status == NDIS_STATUS_SUCCESS) {
			ErrorStatus = NDIS_STATUS_SUCCESS;
		}
		XPACKETBindAdapterComplete((NDIS_HANDLE)pOpenInstance, pOpenInstance->Status, ErrorStatus);
	} else {
		while(pOpenInstance->Status == NDIS_STATUS_PENDING) {
			mSleep(1);
		}
	}
	
	*pStatus = pOpenInstance->Status;
	
	for(Index=0; Index < MAX_RECVQ_LENGTH; Index++) {
		XPACKETAllocateMemory((PVOID *)&pOpenInstance->RecvQueue[Index].lpBuffer,
								MAX_BUFFER_LENGTH);
		if(pOpenInstance->RecvQueue[Index].lpBuffer == NULL) break;
		pOpenInstance->RecvQueue[Index].Status = XPACKET_RX_FREE;
	}		
	pOpenInstance->RecvQMaxEntries = Index;
	pOpenInstance->RecvHead = 0;
	pOpenInstance->RecvTail = 0;

	pOpenInstance->Flushing = XPACKET_FLUSHING;	//March 21, 1998

	return;
}


VOID NDIS_API
XPACKETBindAdapterComplete(
	IN NDIS_HANDLE  ProtocolBindingContext,
	IN NDIS_STATUS  Status,
	IN NDIS_STATUS  OpenErrorStatus )
{
	POPEN_INSTANCE	pOpenInstance = (POPEN_INSTANCE)ProtocolBindingContext;

#ifdef	DEBUG
	Debug_Printf("XPACKET:BindAdapterComplete()\n");
#endif

	//if((pOpenInstance->Status == NDIS_STATUS_PENDING) && (Status == NDIS_STATUS_SUCCESS)) {
	//	NdisCompleteBindAdapter(ProtocolBindingContext, Status, OpenErrorStatus );
	//	pOpenInstance->Status = NDIS_STATUS_SUCCESS;
	//}

	if(Status != NDIS_STATUS_SUCCESS ) {
		NdisFreePacketPool(pOpenInstance->hPacketPool); 
		NdisFreeBufferPool(pOpenInstance->hBufferPool);
		XPACKETFreeMemory((PVOID)pOpenInstance);
		return;
	}

	pOpenInstance->pNextOpenInstance = XPACKETContext.pNextOpenInstance;
	XPACKETContext.pNextOpenInstance = pOpenInstance;

	XPACKETContext.dwOpenInstances++;

	pOpenInstance->Status = Status;

	return;
}

VOID NDIS_API
XPACKETUnbindAdapter(
	OUT PNDIS_STATUS	pStatus,
   	IN NDIS_HANDLE		ProtocolBindingContext,
	IN NDIS_HANDLE		UnbindContext 
	)
{
	POPEN_INSTANCE	pOpenInstance = (POPEN_INSTANCE)ProtocolBindingContext;

#ifdef	DEBUG
	Debug_Printf("XPACKET:UnbindAdapter()\n");
#endif

	// close the adapter
	NdisCloseAdapter(pStatus, pOpenInstance->hAdapter);

	// Save status returned from NdisCloseAdapter for completion routine
	pOpenInstance->Status = *pStatus;

	if(*pStatus != NDIS_STATUS_PENDING ) {
   		XPACKETUnbindAdapterComplete(pOpenInstance, *pStatus);
	}

	return;
}

VOID NDIS_API
XPACKETUnbindAdapterComplete( 
	IN NDIS_HANDLE ProtocolBindingContext,
	IN NDIS_STATUS Status
	)
{
	POPEN_INSTANCE	pOpenInstance = (POPEN_INSTANCE)ProtocolBindingContext;
	PXPACKET_LOCK	pXPacketLock;
	UINT			Index;

#ifdef	DEBUG
	Debug_Printf("XPACKET:UnbindAdapterComplete()\n");
#endif

	if((pOpenInstance->Status == NDIS_STATUS_PENDING) && (Status == NDIS_STATUS_SUCCESS)){
		NdisCompleteUnbindAdapter(ProtocolBindingContext, Status);
		pOpenInstance->Status = NDIS_STATUS_SUCCESS;
	}

	for(Index=0; Index < pOpenInstance->RecvQMaxEntries; Index++) {
		XPACKETFreeMemory((PVOID)pOpenInstance->RecvQueue[Index].lpBuffer);
		pOpenInstance->RecvQueue[Index].cbBuffer = 0;
		pOpenInstance->RecvQueue[Index].Status = XPACKET_RX_CAOS;
	}
	pOpenInstance->RecvQMaxEntries = 0;
	pOpenInstance->RecvHead = 0;
	pOpenInstance->RecvTail = 0;
	
	NdisFreePacketPool(pOpenInstance->hPacketPool); 
	NdisFreeBufferPool(pOpenInstance->hBufferPool); 

	XPACKETContext.pNextOpenInstance = pOpenInstance->pNextOpenInstance;
	XPACKETFreeMemory((PVOID)pOpenInstance);

	XPACKETContext.dwOpenInstances--;

	pXPacketLock = &XPACKETContext.UnbindAdapterLock;
	if(pXPacketLock->Status == XPACKET_UNBIND_ADAPTER_PEND) {
		//signal the waiting process
		((LPOVERLAPPED)pXPacketLock->lpoOvrlapped)->O_InternalHigh = Status;
		//async.
		VWIN32_DIOCCompletionRoutine(((LPOVERLAPPED)pXPacketLock->lpoOvrlapped)->O_Internal);
		//unlock
		XPACKETPageUnlock(pXPacketLock->lpoOvrlapped, sizeof(OVERLAPPED));
		pXPacketLock->Status = XPACKET_UNBIND_ADAPTER_FREE;
	}

	return;
}


VOID NDIS_API
XPACKETResetComplete(
    IN NDIS_HANDLE		ProtocolBindingContext,
    IN NDIS_STATUS		Status
    )

{
#ifdef	DEBUG
	Debug_Printf("XPACKET:ResetComplete()\n");
#endif

	return;
}


//
// Only receive Internet Packets
//
NDIS_STATUS NDIS_API
XPACKETReceiveIndicate (
	IN NDIS_HANDLE 	ProtocolBindingContext,
	IN NDIS_HANDLE 	MacReceiveContext,
	IN PVOID	HeaderBuffer,
	IN UINT 	HeaderBufferSize,
	IN PVOID	LookAheadBuffer,
	IN UINT 	LookAheadBufferSize,
	IN UINT 	PacketSize
	)
{
	POPEN_INSTANCE	pOpenInstance = (POPEN_INSTANCE)ProtocolBindingContext;
	PXPACKET_LOCK	pXPacketLock;
	PCHAR			pChar;
	UINT			RecvTail, IPLen;
	USHORT			DestPort;

	//5/23/98 for TransferData Ndis Call
	NDIS_STATUS		Status;
	PXPACKET_RESERVED	pXPacketReserved;
	PNDIS_PACKET	pPacket;
	PNDIS_BUFFER	pBuffer;
	UINT			nBytesTransfered;


#ifdef	DEBUG
	//Debug_Printf("XPACKET:RI(%u,%u)\n", LookAheadBufferSize, PacketSize);
#endif

	if(pOpenInstance->Flushing == XPACKET_FLUSHING) {
		return	(NDIS_STATUS_NOT_ACCEPTED);
	}

	if(pOpenInstance->RecvQMaxEntries == 0) {
		return	(NDIS_STATUS_NOT_ACCEPTED);
	}

	if(HeaderBufferSize != 14) {	
		// Illegal Ethernet Header
		return	(NDIS_STATUS_NOT_ACCEPTED);
	}

	//ONLY IP
	//if((((UCHAR *)HeaderBuffer)[12] != 0x08) || (((UCHAR *)HeaderBuffer)[13] != 0x00)) {
	//	return	(NDIS_STATUS_NOT_ACCEPTED);
	//}


	if(PacketSize > LookAheadBufferSize) {
		NdisAllocatePacket(&Status,	&pPacket, pOpenInstance->hPacketPool);
		if(Status != NDIS_STATUS_SUCCESS) {
			return NDIS_STATUS_NOT_ACCEPTED;
		}

		//copy the header portion of the received frame
		RecvTail = pOpenInstance->RecvTail;
		pChar = pOpenInstance->RecvQueue[RecvTail].lpBuffer;
		memcpy((PVOID)pChar, (PVOID)HeaderBuffer, HeaderBufferSize);

		pXPacketReserved = PACKET_RESERVE(pPacket);
		//pXPacketReserved->lpBuffer = XPACKETPageLock((DWORD)pChar, PacketSize+HeaderBufferSize);
		pXPacketReserved->lpBuffer = (DWORD)pChar;
		pXPacketReserved->cbBuffer = PacketSize+HeaderBufferSize;
		pXPacketReserved->lpoOvrlapped = 0;
		pXPacketReserved->lpcbBytesReturned = 0;

		NdisAllocateBuffer(&Status,&pBuffer,pOpenInstance->hBufferPool,(PVOID)(pChar+HeaderBufferSize),PacketSize);
		if(Status != NDIS_STATUS_SUCCESS) {
			XPACKETPageUnlock(pXPacketReserved->lpBuffer, pXPacketReserved->cbBuffer);
			NdisReinitializePacket(pPacket);
			NdisFreePacket(pPacket);
			return NDIS_STATUS_NOT_ACCEPTED;
		}

		NdisChainBufferAtFront(pPacket, pBuffer);
		NdisTransferData(&Status, pOpenInstance->hAdapter,MacReceiveContext,0,PacketSize,pPacket,&nBytesTransfered); 
		if(Status != NDIS_STATUS_PENDING) {
			XPACKETTransferDataComplete(ProtocolBindingContext,pPacket,Status,nBytesTransfered);
		}
	} else {
		pXPacketLock = &pOpenInstance->RecvPendQueue;
		if(pXPacketLock->Status == XPACKET_RX_PEND) {
			//signal the waiting process
			((LPOVERLAPPED)pXPacketLock->lpoOvrlapped)->O_InternalHigh = 
											LookAheadBufferSize + HeaderBufferSize;
			pChar = (PCHAR)pXPacketLock->lpBuffer;
			memcpy((PVOID)pChar, (PVOID)HeaderBuffer, HeaderBufferSize);
			memcpy((PVOID)(pChar+HeaderBufferSize), (PVOID)LookAheadBuffer, LookAheadBufferSize);
			//async.
			VWIN32_DIOCCompletionRoutine(((LPOVERLAPPED)pXPacketLock->lpoOvrlapped)->O_Internal);
			//unlock
			XPACKETPageUnlock(pXPacketLock->lpBuffer, pXPacketLock->cbBuffer);
			XPACKETPageUnlock(pXPacketLock->lpoOvrlapped, sizeof(OVERLAPPED));
			pXPacketLock->Status = XPACKET_RX_FREE;
	
			return	(NDIS_STATUS_SUCCESS);
		}

		RecvTail = pOpenInstance->RecvTail;
		if(pOpenInstance->RecvQueue[RecvTail].Status == XPACKET_RX_READY) {
			pOpenInstance->RecvHead = XPACKET_MOD_INC(pOpenInstance->RecvHead,
														pOpenInstance->RecvQMaxEntries);
		}

		pChar = pOpenInstance->RecvQueue[RecvTail].lpBuffer;
		memcpy((PVOID)pChar, (PVOID)HeaderBuffer, HeaderBufferSize);
		memcpy((PVOID)(pChar+HeaderBufferSize), (PVOID)LookAheadBuffer, LookAheadBufferSize);
		pOpenInstance->RecvQueue[RecvTail].cbBuffer = LookAheadBufferSize + HeaderBufferSize;
		pOpenInstance->RecvQueue[RecvTail].Status = XPACKET_RX_READY;
		pOpenInstance->RecvTail = XPACKET_MOD_INC(RecvTail,pOpenInstance->RecvQMaxEntries);
	}

   	return NDIS_STATUS_SUCCESS;
}


VOID NDIS_API
XPACKETTransferDataComplete (
	IN NDIS_HANDLE   	ProtocolBindingContext,
	IN PNDIS_PACKET 	pPacket,
	IN NDIS_STATUS   	Status,
	IN UINT				BytesTransfered
	)
{
	POPEN_INSTANCE		pOpenInstance = (POPEN_INSTANCE)ProtocolBindingContext;
	PXPACKET_RESERVED	pXPacketReserved;
	PNDIS_BUFFER		pBuffer;
	PCHAR				pChar;
	UINT				RecvTail;
	PXPACKET_LOCK		pXPacketLock;


#ifdef	DEBUG
        Debug_Printf("XPACKET:TransferDataComplete(%u)\n", BytesTransfered);
#endif

	NdisUnchainBufferAtFront(pPacket, &pBuffer);
	if(pBuffer!=NULL) {
		NdisFreeBuffer(pBuffer);
	}

	pXPacketReserved = PACKET_RESERVE(pPacket);
	//XPACKETPageUnlock(pXPacketReserved->lpBuffer, pXPacketReserved->cbBuffer);
	//pChar = (PCHAR)pXPacketReserved->lpBuffer;

	pXPacketLock = &pOpenInstance->RecvPendQueue;
	if(pXPacketLock->Status == XPACKET_RX_PEND) {
		//signal the waiting process
		((LPOVERLAPPED)pXPacketLock->lpoOvrlapped)->O_InternalHigh = pXPacketReserved->cbBuffer;
		pChar = (PCHAR)pXPacketLock->lpBuffer;
		memcpy((PVOID)pChar, (PVOID)pXPacketReserved->lpBuffer, pXPacketReserved->cbBuffer);
		//async.
		VWIN32_DIOCCompletionRoutine(((LPOVERLAPPED)pXPacketLock->lpoOvrlapped)->O_Internal);
		//unlock
		XPACKETPageUnlock(pXPacketLock->lpBuffer, pXPacketLock->cbBuffer);
		XPACKETPageUnlock(pXPacketLock->lpoOvrlapped, sizeof(OVERLAPPED));
		pXPacketLock->Status = XPACKET_RX_FREE;

		NdisReinitializePacket(pPacket);
		NdisFreePacket(pPacket);

		return;
	}

	RecvTail = pOpenInstance->RecvTail;
	if(pOpenInstance->RecvQueue[RecvTail].Status == XPACKET_RX_READY) {
		pOpenInstance->RecvHead = XPACKET_MOD_INC(pOpenInstance->RecvHead, pOpenInstance->RecvQMaxEntries);
	}

	pOpenInstance->RecvQueue[RecvTail].cbBuffer = pXPacketReserved->cbBuffer;
	pOpenInstance->RecvQueue[RecvTail].Status = XPACKET_RX_READY;
	pOpenInstance->RecvTail = XPACKET_MOD_INC(RecvTail,pOpenInstance->RecvQMaxEntries);

	NdisReinitializePacket(pPacket);
	NdisFreePacket(pPacket);

	return;
}


VOID NDIS_API
XPACKETReceiveComplete(
	IN NDIS_HANDLE	ProtocolBindingContext
	)
{
#ifdef	DEBUG
	//Debug_Printf("XPACKET:RC\n");
#endif
	return;
}


VOID NDIS_API
XPACKETRequestComplete(
	IN NDIS_HANDLE		ProtocolBindingContext,
	IN PNDIS_REQUEST	pNdisRequest,
	IN NDIS_STATUS		Status 
	)
{
	POPEN_INSTANCE	pOpenInstance = (POPEN_INSTANCE)ProtocolBindingContext;
	BOOL			fQuery;		// if TRUE, Query
	DWORD			cbBytesReturned;

#ifdef	DEBUG
	Debug_Printf("XPACKET:RequestComplete()\n");
#endif

	if(pNdisRequest->RequestType == NdisRequestQueryInformation) {
		fQuery = TRUE;
	} else {
		fQuery = FALSE;
	}

	if(Status == NDIS_STATUS_SUCCESS) {
		if(fQuery == TRUE)	{
			cbBytesReturned = (DWORD)pNdisRequest->DATA.QUERY_INFORMATION.BytesWritten;
		} else {
			cbBytesReturned = (DWORD)pNdisRequest->DATA.SET_INFORMATION.BytesRead;		
		}
	} else {
		cbBytesReturned = 0;
	}

	// save the results
	if(pOpenInstance->Status != NDIS_STATUS_PENDING) {
		if(pOpenInstance->lpcbBytesReturned != 0)
			*((LPDWORD)pOpenInstance->lpcbBytesReturned) = cbBytesReturned;
	} else {
		pOpenInstance->Status = Status;
	}
	if(pOpenInstance->lpoOvrlapped != 0)
		((LPOVERLAPPED)pOpenInstance->lpoOvrlapped)->O_InternalHigh = cbBytesReturned;

    if(pOpenInstance->lpoOvrlapped != 0) {
		VWIN32_DIOCCompletionRoutine(((LPOVERLAPPED)pOpenInstance->lpoOvrlapped)->O_Internal);
	}

	// unlock
	if(pOpenInstance->lpBuffer != 0)
		XPACKETPageUnlock(pOpenInstance->lpBuffer, pOpenInstance->cbBuffer);
	//if(pOpenInstance->lpcbBytesReturned != 0)
	//	XPACKETPageUnlock(pOpenInstance->lpcbBytesReturned, sizeof(DWORD));
	if(pOpenInstance->lpoOvrlapped != 0)
		XPACKETPageUnlock(pOpenInstance->lpoOvrlapped, sizeof(OVERLAPPED));

	pOpenInstance->Status = Status;

#ifdef	DEBUG
	Debug_Printf("XPACKET:RequestComplete() Return\n");
#endif

	return;
}

VOID NDIS_API
XPACKETSendComplete(
	IN NDIS_HANDLE	ProtocolBindingContext,
	IN PNDIS_PACKET	pPacket,
	IN NDIS_STATUS	Status
	)
{
	POPEN_INSTANCE	pOpenInstance = (POPEN_INSTANCE)ProtocolBindingContext;
	PNDIS_BUFFER		pBuffer;
	PXPACKET_RESERVED	pXPacketReserved;

#ifdef	DEBUG
	Debug_Printf("XPACKET:SendComplete()\n");
#endif

	if(pPacket == NULL) {
#ifdef	DEBUG
		Debug_Printf("pPacket NULL\n");
#endif
        return; 
	}

	NdisUnchainBufferAtFront(pPacket, &pBuffer);
	NdisFreeBuffer(pBuffer);

	pXPacketReserved = PACKET_RESERVE(pPacket);
	if(pOpenInstance->Status != NDIS_STATUS_PENDING) {
		if(pXPacketReserved->lpcbBytesReturned != 0) {
			*((LPDWORD)pXPacketReserved->lpcbBytesReturned) = pXPacketReserved->cbBuffer;
		}
	} else {
		pOpenInstance->Status = Status;
	}

	if(pXPacketReserved->lpoOvrlapped != 0) {
		((LPOVERLAPPED)pXPacketReserved->lpoOvrlapped)->O_InternalHigh = pXPacketReserved->cbBuffer;
	}

	// May have some intervals between this entry time and W32DeviceIoControl return time.
	// So, that's no matter to do the below stuff.
    if(pXPacketReserved->lpoOvrlapped != 0)	{
		VWIN32_DIOCCompletionRoutine(((LPOVERLAPPED)pXPacketReserved->lpoOvrlapped)->O_Internal);
	}

    if(pXPacketReserved->lpBuffer != 0)	{
		XPACKETPageUnlock(pXPacketReserved->lpBuffer, pXPacketReserved->cbBuffer);
	}
    //if(pXPacketReserved->lpcbBytesReturned != 0){
	//	XPACKETPageUnlock(pXPacketReserved->lpcbBytesReturned, sizeof(DWORD));
	//}
    if(pXPacketReserved->lpoOvrlapped != 0){
		XPACKETPageUnlock(pXPacketReserved->lpoOvrlapped, sizeof(OVERLAPPED));
	}

	NdisReinitializePacket(pPacket);
	NdisFreePacket(pPacket);

#ifdef	DEBUG
	Debug_Printf("XPACKET:SendComplete() Return\n");
#endif

	return;
}

NDIS_STATUS __stdcall
XPACKETRequestIoControl(
		IN POPEN_INSTANCE	pOpenInstance,
		IN NDIS_OID			Oid,
		IN DWORD			lpBuffer,
		IN DWORD			cbBuffer,
		IN DWORD			lpcbBytesReturned,			
		IN LPOVERLAPPED		lpoOvrlapped,
		IN BOOL				fQuery		// if TRUE, query
		)
{
	NDIS_STATUS		Status;
	PNDIS_REQUEST	pNdisRequest;

	pNdisRequest = &pOpenInstance->NdisRequest;

	// lock
	if(lpBuffer != 0 && cbBuffer > 0) {
		pOpenInstance->lpBuffer = XPACKETPageLock((DWORD)lpBuffer, cbBuffer);
		pOpenInstance->cbBuffer = cbBuffer;
	} else {
		pOpenInstance->lpBuffer = 0;
		pOpenInstance->cbBuffer = 0;
	}

	//if(lpcbBytesReturned != 0) {
	//	pXPACKETContext->lpcbBytesReturned = XPACKETPageLock((DWORD)lpcbBytesReturned, 
	//															sizeof(DWORD));
	//} else {
	//	pXPACKETContext->lpcbBytesReturned = 0;
	//}
	pOpenInstance->lpcbBytesReturned = lpcbBytesReturned;

	if(lpoOvrlapped != 0) {
		pOpenInstance->lpoOvrlapped = XPACKETPageLock((DWORD)lpoOvrlapped, 
														sizeof(OVERLAPPED));
	} else {
		pOpenInstance->lpoOvrlapped = 0;
	}

	if(fQuery==TRUE) {	// Query-request
		pNdisRequest->RequestType = NdisRequestQueryInformation;
		pNdisRequest->DATA.QUERY_INFORMATION.Oid=Oid;
		pNdisRequest->DATA.QUERY_INFORMATION.InformationBuffer = 
															(PVOID)pOpenInstance->lpBuffer;
		pNdisRequest->DATA.QUERY_INFORMATION.InformationBufferLength = 
															(UINT)pOpenInstance->cbBuffer;
	} else {			// Set-request
		pNdisRequest->RequestType = NdisRequestSetInformation;
		pNdisRequest->DATA.SET_INFORMATION.Oid=Oid;
		pNdisRequest->DATA.SET_INFORMATION.InformationBuffer = 
															(PVOID)pOpenInstance->lpBuffer;
		pNdisRequest->DATA.SET_INFORMATION.InformationBufferLength = 
															(UINT)pOpenInstance->cbBuffer;
	}

	NdisRequest(&Status, pOpenInstance->hAdapter,pNdisRequest);
	if(Status != NDIS_STATUS_PENDING) {
		XPACKETRequestComplete((NDIS_HANDLE)pOpenInstance, &pOpenInstance->NdisRequest, Status);
	} else {
		while(pOpenInstance->Status == NDIS_STATUS_PENDING) {
			mSleep(1);
		}
	}
	
    return (Status);
}

///////////////////////////////////////////////////////////////////////////////////////
// XPACKETAllocateBuffer
// for sending
NDIS_STATUS __stdcall
XPACKETAllocateBuffer(
	IN  POPEN_INSTANCE	pOpenInstance,
	OUT PNDIS_PACKET	*ppPacket,
	IN  DWORD			lpBuffer,
	IN  DWORD			cbBuffer,
	IN  DWORD			lpcbBytesReturned,
   	IN LPOVERLAPPED		lpoOvrlapped
	)
{
	NDIS_STATUS		Status;
	PNDIS_PACKET	pPacket;
	PNDIS_BUFFER	pBuffer;
	PXPACKET_RESERVED	pXPacketReserved;

	NdisAllocatePacket(
		&Status,
		&pPacket,
		pOpenInstance->hPacketPool); 		

	if(Status != NDIS_STATUS_SUCCESS){
		return Status;
	}

	pXPacketReserved = PACKET_RESERVE(pPacket);

	if(lpBuffer != 0 && cbBuffer > 0){
         pXPacketReserved->lpBuffer = XPACKETPageLock(lpBuffer, cbBuffer);
         pXPacketReserved->cbBuffer = cbBuffer;
	} else {
         pXPacketReserved->lpBuffer = 0;
         pXPacketReserved->cbBuffer = 0;
	}

	//if(lpcbBytesReturned != 0) {
	//	pXPacketReserved->lpcbBytesReturned = XPACKETPageLock((DWORD)lpcbBytesReturned, 
	//															sizeof(DWORD));
	//} else {
	//	pXPacketReserved->lpcbBytesReturned = 0;
	//}
	pXPacketReserved->lpcbBytesReturned = lpcbBytesReturned;

	if(lpoOvrlapped != 0) {
		pXPacketReserved->lpoOvrlapped = XPACKETPageLock((DWORD)lpoOvrlapped, 
															sizeof(OVERLAPPED));
	}else {
		pXPacketReserved->lpoOvrlapped = 0;
	}

	NdisAllocateBuffer(
		&Status,
		&pBuffer,
		pOpenInstance->hBufferPool,
		(PVOID)pXPacketReserved->lpBuffer,
		pXPacketReserved->cbBuffer
		); 

	if(Status != NDIS_STATUS_SUCCESS) {
		NdisReinitializePacket(pPacket);
		NdisFreePacket(pPacket);

		// Error (Sent bytes# = 0)
		if(pXPacketReserved->lpcbBytesReturned != 0)
			*((LPDWORD)pXPacketReserved->lpcbBytesReturned) = 0;
		if(pXPacketReserved->lpoOvrlapped != 0)
			((LPOVERLAPPED)pXPacketReserved->lpoOvrlapped)->O_InternalHigh = 0;

		if(pXPacketReserved->lpBuffer != 0)
			XPACKETPageUnlock(pXPacketReserved->lpBuffer, pXPacketReserved->cbBuffer);
		//if(pXPacketReserved->lpcbBytesReturned != 0)
		//	XPACKETPageUnlock(pXPacketReserved->lpcbBytesReturned, sizeof(DWORD));
		if(pXPacketReserved->lpoOvrlapped != 0)
			XPACKETPageUnlock(pXPacketReserved->lpoOvrlapped, sizeof(OVERLAPPED));

		return Status;
	}

	NdisChainBufferAtFront(pPacket, pBuffer);
	*ppPacket = pPacket;
	
	return NDIS_STATUS_SUCCESS;
}



//++
///////////////////////////////////////////////////////////////////////////////////////
// XPACKETGetOpenInstance
//
POPEN_INSTANCE	__stdcall
XPACKETGetOpenInstance(
	DWORD		VMHandle,
	DWORD		hDevice,
	DWORD		tagProcess
	)
{
	POPEN_INSTANCE	pOpenInstance;

	pOpenInstance = XPACKETContext.pNextOpenInstance;
	while(pOpenInstance != NULL) {
		if(pOpenInstance->ProcessFace.VMHandle == VMHandle &&
			pOpenInstance->ProcessFace.hDevice == hDevice &&
			pOpenInstance->ProcessFace.tagProcess == tagProcess) {
			return (pOpenInstance);	
		}
		pOpenInstance = pOpenInstance->pNextOpenInstance;
	}
	return  NULL;
}

//++
///////////////////////////////////////////////////////////////////////////////////////
// NdisSendHook
// for hooking NdisSend
void _stdcall NdisSendHook(
	OUT PNDIS_STATUS	Status,
	IN NDIS_HANDLE		NdisBindingHandle,
	IN PNDIS_PACKET		pPacket
	)
{
	PNDIS_BUFFER    pBuffer;
	UCHAR           *pData, *pPrevData;
	DWORD			Length;
	USHORT			DestPort;

	pBuffer = NULL;
	if(pPacket != NULL) {
		//1st buffer
		pBuffer=pPacket->Private.Head;
		pData = (UCHAR *)pBuffer->VirtualAddress;
		Length = pBuffer->Length;

		if((pData==NULL) || (Length!=14) || (pData[12]!=0x08) || (pData[13]!=0x00)) {
			//only IP datagram we're interested in.
			return;
		}
		//2nd buffer (IP datagram only)
		pPrevData = pData;
		pBuffer=(PNDIS_BUFFER)pBuffer->Next;
		pData = (UCHAR *)pBuffer->VirtualAddress;
		Length = pBuffer->Length;

		if((pData==NULL) || (Length<20)) {
			// min. length of IP datagram is 20.
			// min. length of TCP segment is 20.
			return;
		}

		Length =(pData[0]&0x0F)*4; //ip header length
		DestPort = (USHORT)(pData[Length+2]*256+pData[Length+3]);

		//do some work here
		//...

	} // fi(pPacket != NULL)

	return;
}
