/****************************************************************************
 * Written by Sang-Eun Han (seh@brabo1.korea.ac.kr).
 * 
 * 
 * Date : July 28, 1997 (Ver.1.0.0)
 *        98/1/1 (ver. 1.1.0)
 *        March 13, 1998
 *
 * Filename : ZPacket.c
 *
 * PERMISSION IS GRANTED TO USE, COPY AND DISTRIBUTE THIS SOFTWARE FOR ANY 
 * PURPOSE EXCEPT FOR A BUSINESS OR COMMERCIAL PURPOSE, AND WITHOUT FEE, PROVIDED, 
 * THAT THE ABOVE COPYRIGHT NOTICE AND THIS STATEMENT APPEAR IN ALL COPIES.
 * I MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS
 * SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS PROVIDED "AS IS."
 *
 */

#include <string.h>
#pragma intrinsic(memcpy, memcmp, memset, strcat, strcmp, strcpy, strlen)

#pragma warning(disable:4201 4514 4100 4127)

#include <ndis.h>
#include <basedef.h>
#include <vmm.h>
#include <debug.h>
#include <vwin32.h>

#include "ZPacket.h"
#include "ZNdis.h"
#include "ZUtil.h"

#pragma VxD_LOCKED_CODE_SEG
#pragma VxD_LOCKED_DATA_SEG

DWORD __stdcall OnW32DeviceIoControl(
		DWORD  		dwService,	// service code
		DWORD  		dwDDB,		// VM handle
		DWORD  		hDevice,	// Ring3 device handle
		PDIOCPARAMETERS lpDioctl)
{
	NDIS_STATUS 	Status;
	POPEN_INSTANCE	pOpenInstance;
	PXPACKET_BUFFER	pXPacketBuffer;
	PXPACKET_LOCK	pXPacketLock;
	PNDIS_PACKET	pPacket;
	DWORD			nCount;
	UINT			Index;
	
	NDIS_STRING		AdapterName;
	PROCESS_FACE	ProcessFace;

	if(!lpDioctl) {
		return (DWORD)0xffffffff;
	}

	switch(dwService) {
	// DIOC_OPEN
	case DIOC_OPEN:
			return	0;

	// DIOC_CLOSEHANDLE
	case DIOC_CLOSEHANDLE:
			return	0;

	// ZPACKET_BIND
	case IOCTL_ZPACKET_BIND:
		if(lpDioctl->lpoOverlapped == 0) {
			//can't do async. op.
			if(lpDioctl->lpcbBytesReturned != 0)
				*(LPDWORD)lpDioctl->lpcbBytesReturned = NDIS_STATUS_FAILURE;
			return	0;
		}
		if(lpDioctl->lpvInBuffer == 0 || lpDioctl->cbInBuffer == 0){
			//empty buffer ? xxx
			if(lpDioctl->lpcbBytesReturned != 0)
				*(LPDWORD)lpDioctl->lpcbBytesReturned = NDIS_STATUS_FAILURE;
			return	0;
		}
		pXPacketLock = &XPACKETContext.BindAdapterLock;
		if(pXPacketLock->Status == XPACKET_BIND_ADAPTER_PEND) {
			//pre-request is pending. Don't serve this request.
			//try later if you're not busy
			if(lpDioctl->lpcbBytesReturned != 0)
				*(LPDWORD)lpDioctl->lpcbBytesReturned = NDIS_STATUS_ADAPTER_NOT_READY;
			return	0;
		}
		pXPacketLock->lpBuffer = XPACKETPageLock((DWORD)lpDioctl->lpvInBuffer, (DWORD)lpDioctl->cbInBuffer);
		pXPacketLock->cbBuffer = lpDioctl->cbInBuffer;
		pXPacketLock->lpoOvrlapped = XPACKETPageLock((DWORD)lpDioctl->lpoOverlapped, sizeof(OVERLAPPED));
		pXPacketLock->Status = XPACKET_BIND_ADAPTER_PEND;
		//pXPacketLock->lpcbBytesReturned = XPACKETPageLock((DWORD)lpDioctl->lpcbBytesReturned, sizeof(DWORD));

		nCount = strlen((LPCHAR)pXPacketLock->lpBuffer);
		AdapterName.Length=(int)nCount;
		AdapterName.MaximumLength=(int)nCount;
		AdapterName.Buffer=(LPCHAR)pXPacketLock->lpBuffer;

		ProcessFace.VMHandle = lpDioctl->VMHandle;
		ProcessFace.hDevice = lpDioctl->hDevice;
		ProcessFace.tagProcess = lpDioctl->tagProcess;

		XPACKETBindAdapter(&Status,	NULL, &AdapterName, NULL, (PVOID)&ProcessFace);

		if(Status != NDIS_STATUS_PENDING) {
			if(lpDioctl->lpcbBytesReturned != 0) {
				*(LPDWORD)lpDioctl->lpcbBytesReturned = Status;
			}
			return 0;
		} else {
			return (DWORD)0xffffffff;
		}

	case IOCTL_ZPACKET_UNBIND:
	case IOCTL_ZPACKET_CLEAR_PEND: 
			pOpenInstance = XPACKETGetOpenInstance(lpDioctl->VMHandle, lpDioctl->hDevice, lpDioctl->tagProcess);
			if(pOpenInstance == NULL) {
				if(lpDioctl->lpcbBytesReturned != 0)
					*(LPDWORD)lpDioctl->lpcbBytesReturned = NDIS_STATUS_FAILURE;
				return	0;
			}
			pOpenInstance->Flushing = XPACKET_FLUSHING;
			pXPacketLock = &pOpenInstance->RecvPendQueue;
			if(pXPacketLock->Status == XPACKET_RX_PEND) {
				//signal the waiting process
				((LPOVERLAPPED)pXPacketLock->lpoOvrlapped)->O_InternalHigh = 0;
				//async.
				VWIN32_DIOCCompletionRoutine(((LPOVERLAPPED)pXPacketLock->lpoOvrlapped)->O_Internal);
				//unlock
				XPACKETPageUnlock(pXPacketLock->lpBuffer, pXPacketLock->cbBuffer);
				XPACKETPageUnlock(pXPacketLock->lpoOvrlapped, sizeof(OVERLAPPED));
				pXPacketLock->Status = XPACKET_RX_FREE;
			}
			pOpenInstance->Flushing = 0;

			if(dwService == IOCTL_ZPACKET_UNBIND) {
				if(pOpenInstance == NULL) {
					//zombie? xxx
					if(lpDioctl->lpcbBytesReturned != 0)
						*(LPDWORD)lpDioctl->lpcbBytesReturned = NDIS_STATUS_FAILURE;
					return 0;
				}
				if(lpDioctl->lpoOverlapped == 0) {
					//can't do async. op.
					if(lpDioctl->lpcbBytesReturned != 0)
						*(LPDWORD)lpDioctl->lpcbBytesReturned = NDIS_STATUS_FAILURE;
					return	0;
				}
				pXPacketLock = &XPACKETContext.UnbindAdapterLock;
				if(pXPacketLock->Status == XPACKET_UNBIND_ADAPTER_PEND) {
					//pre-request is pending. Don't serve this request.
					//try later if you're not busy
					if(lpDioctl->lpcbBytesReturned != 0)
						*(LPDWORD)lpDioctl->lpcbBytesReturned = NDIS_STATUS_ADAPTER_NOT_READY;
					return	0;
				}
				pXPacketLock->lpoOvrlapped = XPACKETPageLock((DWORD)lpDioctl->lpoOverlapped, sizeof(OVERLAPPED));
				pXPacketLock->Status = XPACKET_UNBIND_ADAPTER_PEND;

				XPACKETUnbindAdapter(&Status, pOpenInstance, NULL);

				if(Status == NDIS_STATUS_PENDING) {
					return (DWORD)0xffffffff;
				} else {
					if(lpDioctl->lpcbBytesReturned != 0) 
						*(LPDWORD)lpDioctl->lpcbBytesReturned = Status;
				}
			}

			return 0;

	// ZPACKET_RECEIVE
	// if RecvQueue is empty, then asynchronous mode starts.(98/1/21)
	//
	case IOCTL_ZPACKET_RECEIVE:
		pOpenInstance = XPACKETGetOpenInstance(lpDioctl->VMHandle, lpDioctl->hDevice, lpDioctl->tagProcess);
		if(pOpenInstance == NULL) {
			if(lpDioctl->lpcbBytesReturned != 0)
				*(LPDWORD)lpDioctl->lpcbBytesReturned = 0;
			return	0;
		}

		if(pOpenInstance->Flushing == XPACKET_FLUSHING) {
			if(lpDioctl->lpcbBytesReturned != 0)
				*(LPDWORD)lpDioctl->lpcbBytesReturned = 0;
			return	0;
		}

		//not ready
		if(pOpenInstance->RecvQMaxEntries == 0) {
			if(lpDioctl->lpcbBytesReturned != 0)
				*(LPDWORD)lpDioctl->lpcbBytesReturned = 0;
			return	0;
		}

		//empty
		if(pOpenInstance->RecvQueue[pOpenInstance->RecvHead].Status == XPACKET_RX_FREE) {
			if(lpDioctl->lpoOverlapped == 0) {
				//can't do async. rx. op.
				if(lpDioctl->lpcbBytesReturned != 0)
					*(LPDWORD)lpDioctl->lpcbBytesReturned = 0;
				return	0;
			}
			if(lpDioctl->lpvOutBuffer == 0 || lpDioctl->cbOutBuffer == 0){
				//empty rx buffer ? xxx
				if(lpDioctl->lpcbBytesReturned != 0)
					*(LPDWORD)lpDioctl->lpcbBytesReturned = 0;
				return	0;
			}
			pXPacketLock = &pOpenInstance->RecvPendQueue;
			if(pXPacketLock->Status == XPACKET_RX_PEND) {
				//signal the already waiting process
				((LPOVERLAPPED)pXPacketLock->lpoOvrlapped)->O_InternalHigh = 0;
				//async.
				VWIN32_DIOCCompletionRoutine(((LPOVERLAPPED)pXPacketLock->lpoOvrlapped)->O_Internal);
				//unlock
				XPACKETPageUnlock(pXPacketLock->lpBuffer, pXPacketLock->cbBuffer);
				XPACKETPageUnlock(pXPacketLock->lpoOvrlapped, sizeof(OVERLAPPED));
			}
			pXPacketLock->lpBuffer = XPACKETPageLock(lpDioctl->lpvOutBuffer, lpDioctl->cbOutBuffer);
			pXPacketLock->cbBuffer = lpDioctl->cbOutBuffer;
			pXPacketLock->lpoOvrlapped = XPACKETPageLock((DWORD)lpDioctl->lpoOverlapped, sizeof(OVERLAPPED));
			pXPacketLock->Status = XPACKET_RX_PEND;

			return	(DWORD)0xffffffff;
		}

		pXPacketBuffer = &pOpenInstance->RecvQueue[pOpenInstance->RecvHead];
		if((lpDioctl->lpvOutBuffer != 0) && (pXPacketBuffer->cbBuffer > 0)) {
			nCount = ((lpDioctl->cbOutBuffer) > (pXPacketBuffer->cbBuffer))? 
						(pXPacketBuffer->cbBuffer) : (lpDioctl->cbOutBuffer);
			memcpy((PVOID)lpDioctl->lpvOutBuffer, (PVOID)pXPacketBuffer->lpBuffer, nCount);
			if(lpDioctl->lpcbBytesReturned != 0)
				*(LPDWORD)lpDioctl->lpcbBytesReturned = nCount;
		}

		pOpenInstance->RecvQueue[pOpenInstance->RecvHead].Status = XPACKET_RX_FREE;
		pOpenInstance->RecvQueue[pOpenInstance->RecvHead].cbBuffer = 0;
		pOpenInstance->RecvHead = XPACKET_MOD_INC(pOpenInstance->RecvHead,
													pOpenInstance->RecvQMaxEntries);

		return 0;

	// ZPACKET_SEND
	//
	case IOCTL_ZPACKET_SEND:
		pOpenInstance = XPACKETGetOpenInstance(lpDioctl->VMHandle, lpDioctl->hDevice, lpDioctl->tagProcess);
		if(pOpenInstance == NULL) {
			if(lpDioctl->lpcbBytesReturned != 0)
				*(LPDWORD)lpDioctl->lpcbBytesReturned = 0;
			return	0;
		}

		Status = XPACKETAllocateBuffer(
					pOpenInstance,	&pPacket,
					lpDioctl->lpvInBuffer, lpDioctl->cbInBuffer,
					lpDioctl->lpcbBytesReturned, (LPOVERLAPPED)lpDioctl->lpoOverlapped);

		if(Status != NDIS_STATUS_SUCCESS) {
			// Sent bytes # is set to zero.
			return (DWORD)0x0;
		}

		NdisSend( &Status, pOpenInstance->hAdapter,	pPacket); 		
		pOpenInstance->Status = Status;
		if(Status != NDIS_STATUS_PENDING){
			XPACKETSendComplete(pOpenInstance, pPacket,	Status);
			//if(lpDioctl->lpcbBytesReturned != 0)
			//	*(LPDWORD)lpDioctl->lpcbBytesReturned = Status;
			return 0;
		} else {
			return (DWORD)0xffffffff;
		}

	//ZPACKET_VENDOR_DESCRIPTION
	case IOCTL_ZPACKET_VENDOR_DESCRIPTION:
		pOpenInstance = XPACKETGetOpenInstance(lpDioctl->VMHandle, lpDioctl->hDevice, lpDioctl->tagProcess);
		if(pOpenInstance == NULL) {
			if(lpDioctl->lpcbBytesReturned != 0)
				*(LPDWORD)lpDioctl->lpcbBytesReturned = 0;
			return	0;
		}

		Status = XPACKETRequestIoControl (
						pOpenInstance,
						OID_GEN_VENDOR_DESCRIPTION,
						lpDioctl->lpvOutBuffer,
						lpDioctl->cbOutBuffer,
	                	lpDioctl->lpcbBytesReturned,
						(LPOVERLAPPED)lpDioctl->lpoOverlapped, TRUE);
		if(Status != NDIS_STATUS_PENDING) {
			return 0;
		} else {
			return (DWORD)0xffffffff;
		}

	//ZPACKET_MAC_ADDRESS
	case IOCTL_ZPACKET_MAC_ADDRESS:
		pOpenInstance = XPACKETGetOpenInstance(lpDioctl->VMHandle, lpDioctl->hDevice, lpDioctl->tagProcess);
		if(pOpenInstance == NULL) {
			if(lpDioctl->lpcbBytesReturned != 0)
				*(LPDWORD)lpDioctl->lpcbBytesReturned = 0;
			return	0;
		}

		Status = XPACKETRequestIoControl (
						pOpenInstance,
						OID_802_3_CURRENT_ADDRESS,
						lpDioctl->lpvOutBuffer,
						lpDioctl->cbOutBuffer,
	                	lpDioctl->lpcbBytesReturned,
						(LPOVERLAPPED)lpDioctl->lpoOverlapped, TRUE);
		if(Status != NDIS_STATUS_PENDING) {
			return 0;
		} else {
			return (DWORD)0xffffffff;
		}

	// ZPACKET_SET_PACKET_FILTER
	// ZPACKET_FLUSH
	case IOCTL_ZPACKET_SET_PACKET_FILTER:
	case IOCTL_ZPACKET_FLUSH:
		pOpenInstance = XPACKETGetOpenInstance(lpDioctl->VMHandle, lpDioctl->hDevice, lpDioctl->tagProcess);
		if(pOpenInstance == NULL) {
			return	(DWORD)0xffffffff;
		}

		pOpenInstance->Flushing = XPACKET_FLUSHING;	//March 14, 1998

		for(Index=0; Index < pOpenInstance->RecvQMaxEntries; Index++) {
			pOpenInstance->RecvQueue[Index].Status = XPACKET_RX_FREE;
			pOpenInstance->RecvQueue[pOpenInstance->RecvHead].cbBuffer = 0;
		}

		pOpenInstance->RecvHead = 0;
		pOpenInstance->RecvTail = 0;

		pOpenInstance->Flushing = 0;	//March 14, 1998

		if(dwService == IOCTL_ZPACKET_SET_PACKET_FILTER) {
			pOpenInstance = XPACKETGetOpenInstance(lpDioctl->VMHandle, lpDioctl->hDevice, lpDioctl->tagProcess);
			if(pOpenInstance == NULL) {
				if(lpDioctl->lpcbBytesReturned != 0)
					*(LPDWORD)lpDioctl->lpcbBytesReturned = 0;
				return	0;
			}

			Status = XPACKETRequestIoControl (
							pOpenInstance,
							OID_GEN_CURRENT_PACKET_FILTER,
							lpDioctl->lpvInBuffer,
							lpDioctl->cbInBuffer,
							lpDioctl->lpcbBytesReturned,
							(LPOVERLAPPED)lpDioctl->lpoOverlapped, FALSE);

			if(Status == NDIS_STATUS_PENDING) {
				return (DWORD)0xffffffff;
			}
		}

		return 0;

	// DEFAULT case
	default:
		return (DWORD)0xffffffff;
	}
}


NDIS_STATUS __stdcall OnSysDynamicDeviceExit(void)
{
	return NDIS_STATUS_SUCCESS;
}


#pragma	VxD_ICODE_SEG
#pragma	VxD_IDATA_SEG

NDIS_STATUS __stdcall OnSysDynamicDeviceInit(void)
{
        return DriverEntry(NULL, NULL);
}
