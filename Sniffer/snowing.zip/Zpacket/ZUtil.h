/****************************************************************************
 * Written by Sang-Eun Han (seh@brabo1.korea.ac.kr).
 * 
 * Date : July 28, 1997
 *
 * Filename : ZUtil.h
 *
 * PERMISSION IS GRANTED TO USE, COPY AND DISTRIBUTE THIS SOFTWARE FOR ANY 
 * PURPOSE EXCEPT FOR A BUSINESS OR COMMERCIAL PURPOSE, AND WITHOUT FEE, PROVIDED, 
 * THAT THE ABOVE COPYRIGHT NOTICE AND THIS STATEMENT APPEAR IN ALL COPIES.
 * I MAKES NO REPRESENTATIONS ABOUT THE SUITABILITY OF THIS
 * SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS PROVIDED "AS IS."
 *
 */

#ifndef	_ZUTIL_H_
#define _ZUTIL_H_

#ifdef	__cplusplus
extern "C" {
#endif

DWORD _stdcall XPACKETPageLock(DWORD lpMem, DWORD cbSize);
void _stdcall XPACKETPageUnlock(DWORD lpMem, DWORD cbSize);
void _stdcall XPACKETAllocateMemory(PVOID *VirtualMemory, ULONG nBytes);
void _stdcall XPACKETFreeMemory(PVOID VirtualMemory);

#ifdef	__cplusplus
}
#endif

#endif